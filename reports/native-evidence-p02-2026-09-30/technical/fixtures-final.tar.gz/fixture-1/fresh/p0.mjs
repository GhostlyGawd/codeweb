import {popular} from './subject.mjs';
export function p0() {
 return popular(0);
}
