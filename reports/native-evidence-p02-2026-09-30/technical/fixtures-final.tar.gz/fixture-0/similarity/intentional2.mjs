export function duplicate2(cents) {
 return Math.round(cents * 1.2);
}
