export function low(value) {
  return value + 2;
}
export function popular(value) {
  return value * 2;
}
function local(value) {
  return low(value);
}
export function zero(value) {
  return value - 1;
}
