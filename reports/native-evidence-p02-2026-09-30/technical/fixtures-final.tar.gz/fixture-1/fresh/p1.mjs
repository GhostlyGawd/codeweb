import {popular} from './subject.mjs';
export function p1() {
 return popular(1);
}
