export function low(value) {
 return value + 1;
}
export function popular(value) {
 return value * 2;
}
// behind
