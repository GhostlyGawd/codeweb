import test from 'node:test';
import assert from 'node:assert/strict';
import {low} from './subject.mjs';
test('skipped oracle',{skip:true},()=>assert.equal(low(2),999));
