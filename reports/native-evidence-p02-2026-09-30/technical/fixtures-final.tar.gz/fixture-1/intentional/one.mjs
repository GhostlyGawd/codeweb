export function packOrders(list) {
 const out = [];
 let total = 0;
 for (const it of list) {
 total += it.qty;
 out.push(it.qty * 2);
 }
 const avg = total / list.length;
 out.sort();
 console.log(avg);
 return out;
}
