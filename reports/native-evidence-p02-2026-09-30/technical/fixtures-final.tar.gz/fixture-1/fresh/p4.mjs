import {popular} from './subject.mjs';
export function p4() {
 return popular(4);
}
