import test from 'node:test';
import assert from 'node:assert/strict';
import {low} from './subject.mjs';
test('current valid oracle',()=>assert.equal(low(2),3));
