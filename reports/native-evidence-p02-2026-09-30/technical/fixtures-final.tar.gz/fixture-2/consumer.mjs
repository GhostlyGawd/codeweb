import {low} from './subject.mjs';
export function consumer() {
 return low(2);
}
