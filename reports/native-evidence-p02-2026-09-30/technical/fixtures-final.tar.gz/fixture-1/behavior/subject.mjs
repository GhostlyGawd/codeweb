export function low(value) {
 return value + 2;
}
