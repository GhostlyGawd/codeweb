import test from 'node:test';
test('malformed oracle',()=> {
