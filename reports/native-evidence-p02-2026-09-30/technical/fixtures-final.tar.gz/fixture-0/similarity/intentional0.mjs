export function duplicate0(cents) {
 return Math.round(cents * 1.2);
}
