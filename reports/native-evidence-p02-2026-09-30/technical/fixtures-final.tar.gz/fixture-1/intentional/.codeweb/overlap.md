# codeweb — overlap / consolidation opportunities

> **0 findings** · 0 interface patterns · 0 unverified · 0 dismissed (body-refuted) · 1 suppressed (triaged false-positive — codeweb_annotate list shows them) on **codeweb-p02-supplement-mshorI/intentional**.
> Confidence is **body-confirmed** (token-shingle similarity of real function bodies). Each finding is a checklist item.

## Findings

## Unverified candidates

_Borderline body similarity (15–35%); confirm by reading before acting._

## Dismissed (body-refuted)

_Same name, <15% body similarity — different logic, not duplication. Listed for transparency (no silent truncation)._
