export function addTax(cents) {
 return Math.round(cents * 1.2);
}
