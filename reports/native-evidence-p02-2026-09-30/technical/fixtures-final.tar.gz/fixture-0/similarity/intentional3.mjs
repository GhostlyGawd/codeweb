export function duplicate3(cents) {
 return Math.round(cents * 1.2);
}
