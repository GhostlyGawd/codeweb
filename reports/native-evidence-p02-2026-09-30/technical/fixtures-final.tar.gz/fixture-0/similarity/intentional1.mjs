export function duplicate1(cents) {
 return Math.round(cents * 1.2);
}
