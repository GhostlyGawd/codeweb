import {popular} from './subject.mjs';
export function p3() {
 return popular(3);
}
