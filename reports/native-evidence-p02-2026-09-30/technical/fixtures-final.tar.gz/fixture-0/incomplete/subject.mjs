export function low() { return 1; }
