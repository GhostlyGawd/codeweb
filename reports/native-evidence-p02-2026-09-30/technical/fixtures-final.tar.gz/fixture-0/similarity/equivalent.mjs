export function addTaxAlternative(n) {
 const fifth = n / 5;
 const total = n + fifth;
 return Math.floor(total + 0.5);
}
