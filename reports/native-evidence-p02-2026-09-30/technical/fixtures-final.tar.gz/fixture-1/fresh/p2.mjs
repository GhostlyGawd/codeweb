import {popular} from './subject.mjs';
export function p2() {
 return popular(2);
}
