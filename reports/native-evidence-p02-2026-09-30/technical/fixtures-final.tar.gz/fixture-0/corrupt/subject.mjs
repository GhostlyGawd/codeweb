export function standalone() { return 1; }
