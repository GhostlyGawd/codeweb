export function discount(cents) {
 return Math.round(cents * 0.8);
}
